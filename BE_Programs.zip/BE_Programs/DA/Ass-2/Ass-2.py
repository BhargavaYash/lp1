#import libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

#importing Dataset

data_set =pd.read_csv('PimaIndiansDiabetes.csv')
X = data_set.iloc[ : , :-1] #independent variables separated as x
Y=data_set.iloc[ : , -1] #dependent variables into y
print ("IV".center(40, "_" ), '\n' ,X.head())
print("DV".center(40, "_"), '\n' ,Y.head())

#check for missing value
print(X.isnull().any())
print(Y.isnull().any())

#summary
print(X.info())

#turning info row/np format

X = X.values
y = Y.values

#noted the high variance between all feilds
#scalling required

#1.splitting x yinto train and test

from sklearn.model_selection import train_test_split
X_train , X_test , Y_train ,Y_test =train_test_split(X,Y,test_size=0.25 ,random_state=0)

# 2. Scaling
from sklearn.preprocessing import StandardScaler
scaler_X = StandardScaler()
X_train = scaler_X.fit_transform(X_train)
X_test = scaler_X.transform(X_test)

# Machine: Classifier | NB: Gaussian Naive Bayes
from sklearn.naive_bayes import GaussianNB
classifier = GaussianNB()
classifier.fit(X_train, Y_train)

# Predictions
y_pred = classifier.predict(X_test)

#validating predictions using confusion_matrix
from sklearn.metrics import confusion_matrix
cm = confusion_matrix(Y_test,y_pred)
print(cm)

from sklearn.metrics import precision_recall_fscore_support
prf = precision_recall_fscore_support(Y_test,y_pred)
print('\t\t\t\tZero \t\t\t\tONE')
print('Precision\t:',prf[0]*100)
print('Recall\t:',prf[1]*100)
print('F1 mearsure\t:',prf[2]*100)
print('support\t\t:',prf[3])